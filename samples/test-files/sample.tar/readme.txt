TAR archive test file for peekdocs.
This file is inside the tar.