ZIP archive test file for peekdocs.
This file is inside the zip.